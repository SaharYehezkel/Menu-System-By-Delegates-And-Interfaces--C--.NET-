﻿using System;

namespace Ex04.Menus.Delegates
{
    public enum eActionsSelection
    {
        ShowDate = 1,
        ShowTime = 2,
        CountCapitals = 3,
        ShowVersion = 4
    }
}